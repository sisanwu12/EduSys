create definer = root@localhost trigger chk_snum
    before insert
    on schedule
    for each row
BEGIN
        DECLARE Num INT;
        select room.Capacity INTO Num
        FROM room
        where room.RID = NEW.RID;
        IF NEW.SNUM > Num THEN
            SIGNAL SQLSTATE '45000' /*用于抛出自定义错误，45000 是通用错误代码。*/
            SET MESSAGE_TEXT = '超出教室容量！';
        end IF;
    END;

